#!/bin/bash

echo "Before appending the file"
cat file.txt

echo "Learning Laravel 5">> file.txt
echo "After appending the file"
cat file.txt
