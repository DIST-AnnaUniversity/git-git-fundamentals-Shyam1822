#!/bin/bash
Recipient=”shyamchess.murali@gmail.com"
Subject=”Greeting”
Message=”Welcome to our site”
mail -s $Subject $Recipient <<< $Message

