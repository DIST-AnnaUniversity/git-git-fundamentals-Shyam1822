#!/bin/bash
function f1()
{
echo 'I like programming'
}

f1
