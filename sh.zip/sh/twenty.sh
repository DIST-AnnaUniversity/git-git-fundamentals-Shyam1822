
#!/bin/bash
function greet() {

str="Hello, $name"
echo $str

}

echo "Enter your name"
read name

val=$(greet)
echo "Return value of the function is $val"
