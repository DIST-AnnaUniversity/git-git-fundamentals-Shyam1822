# !/bin/bash
echo "Printing text with newline"
echo -n "Printing text without newline"
echo -e "\n Removing \t backslash \t characters\n"

