# !/bin/bash

#Add two numerical values
((sum=25+30))

#Print the result
echo $sum
