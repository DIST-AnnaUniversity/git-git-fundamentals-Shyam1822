#!/bin/bash
echo "Enter directory name"
read newdir
mkdir $newdir
