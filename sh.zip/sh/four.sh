# i/bin/bash
echo "Multi line comments"
((area=5*5))
echo $area
